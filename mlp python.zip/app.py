"""
app.py - Aplicação de cadastro de clientes com previsão de inadimplência.

Uso:  python app.py      (antes, rode 'python treinamento.py' uma vez)
"""
import json
import os
import numpy as np
from mlp import MLP
from treinamento import ARQUIVO_MODELO, montar_entradas

ARQUIVO_CLIENTES = "clientes.json"

LEGENDA_PAY = """
  Situação do pagamento em cada mês:
    -2 = não usou o cartão     -1 = pagou a fatura inteira
     0 = pagou só o mínimo      1 a 9 = meses de atraso
"""


# ---------- Entrada de dados com validação ----------
def ler_numero(msg, minimo=None, maximo=None, inteiro=False):
    while True:
        txt = input(msg).strip().replace(",", ".")
        try:
            v = int(txt) if inteiro else float(txt)
        except ValueError:
            print("  ! Valor inválido, tente de novo.")
            continue
        if (minimo is not None and v < minimo) or (maximo is not None and v > maximo):
            print(f"  ! O valor deve estar entre {minimo} e {maximo}.")
            continue
        return v


# ---------- Previsão ----------
def prever_cliente(rede, params, historico_pay, limite, ultimo_pagamento):
    entradas = np.array([montar_entradas(historico_pay, limite, ultimo_pagamento)], dtype=float)
    entradas = (entradas - params["media"]) / params["desvio"]   # mesma normalização do treino
    prob = float(rede.prever_proba(entradas)[0, 0])
    return prob, prob >= float(params["limiar"])


def cadastrar(rede, params):
    print("\n=== CADASTRO DE CLIENTE ===")
    nome = input("Nome do cliente: ").strip() or "Sem nome"
    limite = ler_numero("Limite do cartão (NT$): ", minimo=1)
    print(LEGENDA_PAY)
    meses = ["último mês", "2 meses atrás", "3 meses atrás",
             "4 meses atrás", "5 meses atrás", "6 meses atrás"]
    hist = [ler_numero(f"  Situação {m} (-2 a 9): ", -2, 9, inteiro=True) for m in meses]
    pagto = ler_numero("Valor pago na última fatura (NT$): ", minimo=0)

    prob, inadimplente = prever_cliente(rede, params, hist, limite, pagto)

    print("\n--- RESULTADO DA ANÁLISE ---")
    print(f"Cliente: {nome}")
    print(f"Pontuação de risco (saída da rede): {prob:.1%}")
    if inadimplente:
        print("Previsão: ALTO RISCO - provável que NÃO pague a próxima fatura.")
        print("Sugestão: crédito negado / limite reduzido / análise manual.")
    else:
        print("Previsão: BAIXO RISCO - provável que pague a próxima fatura.")
        print("Sugestão: crédito aprovado.")

    clientes = carregar_clientes()
    clientes.append({"nome": nome, "limite": limite, "historico_pay": hist,
                     "ultimo_pagamento": pagto, "risco": round(prob, 4),
                     "previsao_inadimplente": bool(inadimplente)})
    with open(ARQUIVO_CLIENTES, "w", encoding="utf-8") as f:
        json.dump(clientes, f, ensure_ascii=False, indent=2)
    print("Cliente salvo.")


def carregar_clientes():
    if os.path.exists(ARQUIVO_CLIENTES):
        with open(ARQUIVO_CLIENTES, encoding="utf-8") as f:
            return json.load(f)
    return []


def listar():
    clientes = carregar_clientes()
    if not clientes:
        print("\nNenhum cliente cadastrado.")
        return
    print(f"\n{'Nome':<25}{'Risco':>8}  Previsão")
    for c in clientes:
        status = "ALTO RISCO" if c["previsao_inadimplente"] else "baixo risco"
        print(f"{c['nome']:<25}{c['risco']:>8.1%}  {status}")


def main():
    if not os.path.exists(ARQUIVO_MODELO):
        print("Modelo não encontrado. Rode primeiro:  python treinamento.py")
        return
    rede, params = MLP.carregar(ARQUIVO_MODELO)

    while True:
        print("\n===== ANÁLISE DE CRÉDITO (MLP) =====")
        print("1) Cadastrar cliente e analisar risco")
        print("2) Listar clientes cadastrados")
        print("0) Sair")
        op = input("Opção: ").strip()
        if op == "1":
            cadastrar(rede, params)
        elif op == "2":
            listar()
        elif op == "0":
            break
        else:
            print("Opção inválida.")


if __name__ == "__main__":
    main()
